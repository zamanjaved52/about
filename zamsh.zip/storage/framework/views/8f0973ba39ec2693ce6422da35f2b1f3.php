<?php $__env->startSection('title', 'laraPortfolio - View About'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-3">
        <div class="card mt-4">
            <div class="card-header">
                <h4>About Settings <a href="<?php echo e(route('public.index')); ?>" target="_blank" class="btn btn-primary float-end">Live
                        View</a></h4>
            </div>
            <div class="card-body">
                <?php if(session('msg')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Holy guacamole!</strong> <?php echo e(session('msg')); ?>

                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <div class="card-body text-center">
                                    
                                    <img src="<?php echo e(asset('storage/about_image')); ?>/<?php echo e($about->image); ?>" alt="admin avatar"
                                        class="img-fluid mt-5" style="height: 260px">
                                    

                                    <h5 class="mt-5"><?php echo e($about->nickname != null ? $about->nickname : 'Atlas'); ?></h5>
                                    <p class="text-muted my-2">Admin, laraPortfolio</p>
                                    <p class="text-muted my-2">
                                        <?php echo e($about->city); ?></p>

                                    <div class="pt-2">
                                        <form action="<?php echo e(route('admin.about.update-image')); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="file" name="about_image" class="form-control mt-3">
                                            <p class="text-right" style="color:red;">
                                                <?php $__errorArgs = ['about_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    *<?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </p>
                                            <button type="submit" class="btn btn-outline-primary btn-block"
                                                style="margin: 30px 0px 10px">Update Profile Image</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-7">
                        <div class="card">

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-0">Full Name</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->full_name); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-0">Nickname</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->nickname); ?></p>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-0">Short Description</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->short_description); ?>

                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-0">Designation</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->designation); ?></p>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-0">Birthday</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->birthday); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-0">Age</p>
                                        <p class="text-muted mb-0"><?php echo e($about->age); ?></p>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-0">Gender</p>
                                        <p class="text-muted mb-0"><?php echo e($about->gender); ?>

                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-0">Email</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->email); ?></p>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-0">Phone</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->phone); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-0">Degree</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->degree); ?></p>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-0">City</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->city); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-0">Freelance</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->freelance); ?></p>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-0">Website</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->website_link); ?>

                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-0">CV</p>
                                        <p class="text-muted mb-0">
                                            <?php echo e($about->cv_file != null ? $about->cv_file : 'Not Given'); ?></p>
                                    </div>
                                </div>
                                <div class="row pt-4">
                                    <div class="justify-content-center">
                                        <a href="<?php echo e(route('admin.edit-about')); ?>" class="btn btn-primary mr-1">Edit
                                            Profile</a>
                                        <a href="<?php echo e(route('admin.change-password')); ?>"
                                            class="btn btn-outline-primary">Change
                                            Password</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laraPortfolio_laravel-project\resources\views/admin/about/view-about.blade.php ENDPATH**/ ?>