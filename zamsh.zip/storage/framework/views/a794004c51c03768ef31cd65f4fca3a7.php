<?php $__env->startSection('title', 'laraPortfolio - Home'); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laraPortfolio_laravel-project\resources\views/public/index.blade.php ENDPATH**/ ?>